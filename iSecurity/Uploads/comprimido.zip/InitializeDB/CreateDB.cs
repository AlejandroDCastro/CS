
/*PROTECTED REGION ID(CreateDB_imports) ENABLED START*/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using EjemploDSMGenNHibernate.EN.EjemploDSM;
using EjemploDSMGenNHibernate.CEN.EjemploDSM;
using EjemploDSMGenNHibernate.CAD.EjemploDSM;

/*PROTECTED REGION END*/
namespace InitializeDB
{
public class CreateDB
{
public static void Create (string databaseArg, string userArg, string passArg)
{
        String database = databaseArg;
        String user = userArg;
        String pass = passArg;

        // Conex DB
        SqlConnection cnn = new SqlConnection (@"Server=(local)\sqlexpress; database=master; integrated security=yes");

        // Order T-SQL create user
        String createUser = @"IF NOT EXISTS(SELECT name FROM master.dbo.syslogins WHERE name = '" + user + @"')
            BEGIN
                CREATE LOGIN ["                                                                                                                                     + user + @"] WITH PASSWORD=N'" + pass + @"', DEFAULT_DATABASE=[master], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
            END"                                                                                                                                                                                                                                                                                    ;

        //Order delete user if exist
        String deleteDataBase = @"if exists(select * from sys.databases where name = '" + database + "') DROP DATABASE [" + database + "]";
        //Order create databas
        string createBD = "CREATE DATABASE " + database;
        //Order associate user with database
        String associatedUser = @"USE [" + database + "];CREATE USER [" + user + "] FOR LOGIN [" + user + "];USE [" + database + "];EXEC sp_addrolemember N'db_owner', N'" + user + "'";
        SqlCommand cmd = null;

        try
        {
                // Open conex
                cnn.Open ();

                //Create user in SQLSERVER
                cmd = new SqlCommand (createUser, cnn);
                cmd.ExecuteNonQuery ();

                //DELETE database if exist
                cmd = new SqlCommand (deleteDataBase, cnn);
                cmd.ExecuteNonQuery ();

                //CREATE DB
                cmd = new SqlCommand (createBD, cnn);
                cmd.ExecuteNonQuery ();

                //Associate user with db
                cmd = new SqlCommand (associatedUser, cnn);
                cmd.ExecuteNonQuery ();

                System.Console.WriteLine ("DataBase create sucessfully..");
        }
        catch (Exception ex)
        {
                throw ex;
        }
        finally
        {
                if (cnn.State == ConnectionState.Open) {
                        cnn.Close ();
                }
        }
}

public static void InitializeData ()
{
        /*PROTECTED REGION ID(initializeDataMethod) ENABLED START*/
        try
        {
                CategoriaCEN cen = new CategoriaCEN ();
                int cat1 = cen.New_ ("Perros", @"https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRRO5YpSpaM0oUa-3WmJKgUqGQx9mWminNuDFN5zMWJl-QDsJidwQ");
                int cat2 = cen.New_ ("Gatos", @"http://www.radiopeninsular.com/wp-content/uploads/2015/07/Los-gatos-nos-ignoran-1.jpg");
                cen.New_ ("Pajaros", @"http://elduendedelaradio.files.wordpress.com/2013/04/canarios-amarillos.jpg");
                cen.New_ ("Reptiles", @"http://static.batanga.com/sites/default/files/styles/full/public/curiosidades.batanga.com/files/Por-que-la-cola-de-los-reptiles-vuelve-a-crecer.jpg?itok=98SUWEFx");

                ArticuloCEN artCen = new ArticuloCEN ();
                artCen.New_ ("Perro pincher", 800, cat1, @"http://2.bp.blogspot.com/-lsmCwypewnw/Tn4h8ruH3TI/AAAAAAAAAM0/AkGBJGkuIzg/s1600/Caracteristicas+pincher.PNG", "perro 1");
                artCen.New_ ("Perro bulldog", 670, cat1, @"http://petguide.com.vsassets.com/wp-content/uploads/2013/02/bulldog-1.jpg", "perro 2");
                artCen.New_ ("Perro Caniche", 500, cat1, @"http://www.royalcanin.cl/var/royalcanin/storage/images/breeds/dog-breeds/fci-group-9/caniche/poodle_0026/79845-8-fre-FR/poodle_0026_phototheque.jpg", "perro 3");

                artCen.New_("Gato Persa", 230, cat2, @"http://www.animalclan.com/blog/wp-content/uploads/2014/04/shutterstock_74094664.jpg", "gato1");


                /*List<EjemploDSMGenNHibernate.EN.Mediaplayer.MusicTrackEN> musicTracks = new List<EjemploDSMGenNHibernate.EN.Mediaplayer.MusicTrackEN>();
                 * EjemploDSMGenNHibernate.EN.Mediaplayer.UserEN userEN = new EjemploDSMGenNHibernate.EN.Mediaplayer.UserEN();
                 * EjemploDSMGenNHibernate.EN.Mediaplayer.ArtistEN artistEN = new EjemploDSMGenNHibernate.EN.Mediaplayer.ArtistEN();
                 * EjemploDSMGenNHibernate.EN.Mediaplayer.MusicTrackEN musicTrackEN = new EjemploDSMGenNHibernate.EN.Mediaplayer.MusicTrackEN();
                 * EjemploDSMGenNHibernate.CEN.Mediaplayer.ArtistCEN artistCEN = new EjemploDSMGenNHibernate.CEN.Mediaplayer.ArtistCEN();
                 * EjemploDSMGenNHibernate.CEN.Mediaplayer.UserCEN userCEN = new EjemploDSMGenNHibernate.CEN.Mediaplayer.UserCEN();
                 * EjemploDSMGenNHibernate.CEN.Mediaplayer.MusicTrackCEN musicTrackCEN = new EjemploDSMGenNHibernate.CEN.Mediaplayer.MusicTrackCEN();
                 * EjemploDSMGenNHibernate.CEN.Mediaplayer.PlayListCEN playListCEN = new EjemploDSMGenNHibernate.CEN.Mediaplayer.PlayListCEN();
                 *
                 *              //Add Users
                 * userEN.Email = "user@user.com";
                 * userEN.Name = "user";
                 * userEN.Surname = "userSurname";
                 * userEN.Password = "user";
                 * userCEN.New_(userEN.Name, userEN.Surname, userEN.Email, userEN.Password);
                 *
                 * //Add Music Track1
                 * musicTrackEN.Id = "http://www2.b3ta.com/mp3/Beer Beer Beer (YOB mix).mp3";
                 * musicTrackEN.Format = "mp3";
                 * musicTrackEN.Lyrics = "Beer Beer Beer Beer Beer Beer ..";
                 * musicTrackEN.Name = "Beer Beer Beer";
                 * musicTrackEN.Company = "Company";
                 * musicTrackEN.Cover = "http://www.tomasabraham.com.ar/cajadig/2007/images/nro18-2/beer1.jpg";
                 * musicTrackEN.Price = 20;
                 * musicTrackEN.Rating = 5;
                 * musicTrackEN.CommunityRating = 5;
                 * musicTrackEN.Duration = 200;
                 * musicTrackCEN.New_(musicTrackEN.Id, musicTrackEN.Format, musicTrackEN.Lyrics, musicTrackEN.Name,
                 *  musicTrackEN.Company, musicTrackEN.Cover, musicTrackEN.CommunityRating, musicTrackEN.Rating,
                 *  musicTrackEN.Price, musicTrackEN.Duration);
                 * musicTracks.Add(musicTrackEN);
                 * musicTrackCEN.AsignUser(musicTrackEN.Id,userEN.Email);
                 *
                 * //Define Album
                 * //EjemploDSMGenNHibernate.CEN.Mediaplayer.AlbumCEN albumCEN = new EjemploDSMGenNHibernate.CEN.Mediaplayer.AlbumCEN();
                 * //albumCEN.New_("Album 1", "This is a Album 1", artists, musicTracks);*/
                /*PROTECTED REGION END*/
        }
        catch (Exception ex)
        {
                System.Console.WriteLine (ex.InnerException);
                throw ex;
        }
}
}
}
