
using System;
// Definición clase CategoriaEN
namespace EjemploDSMGenNHibernate.EN.EjemploDSM
{
public partial class CategoriaEN
{
/**
 *	Atributo id
 */
private int id;



/**
 *	Atributo articulo
 */
private System.Collections.Generic.IList<EjemploDSMGenNHibernate.EN.EjemploDSM.ArticuloEN> articulo;



/**
 *	Atributo nombre
 */
private string nombre;



/**
 *	Atributo url
 */
private string url;






public virtual int Id {
        get { return id; } set { id = value;  }
}



public virtual System.Collections.Generic.IList<EjemploDSMGenNHibernate.EN.EjemploDSM.ArticuloEN> Articulo {
        get { return articulo; } set { articulo = value;  }
}



public virtual string Nombre {
        get { return nombre; } set { nombre = value;  }
}



public virtual string Url {
        get { return url; } set { url = value;  }
}





public CategoriaEN()
{
        articulo = new System.Collections.Generic.List<EjemploDSMGenNHibernate.EN.EjemploDSM.ArticuloEN>();
}



public CategoriaEN(int id, System.Collections.Generic.IList<EjemploDSMGenNHibernate.EN.EjemploDSM.ArticuloEN> articulo, string nombre, string url
                   )
{
        this.init (Id, articulo, nombre, url);
}


public CategoriaEN(CategoriaEN categoria)
{
        this.init (Id, categoria.Articulo, categoria.Nombre, categoria.Url);
}

private void init (int id, System.Collections.Generic.IList<EjemploDSMGenNHibernate.EN.EjemploDSM.ArticuloEN> articulo, string nombre, string url)
{
        this.Id = id;


        this.Articulo = articulo;

        this.Nombre = nombre;

        this.Url = url;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        CategoriaEN t = obj as CategoriaEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
