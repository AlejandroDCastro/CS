
using System;
// Definición clase PedidoEN
namespace EjemploDSMGenNHibernate.EN.EjemploDSM
{
public partial class PedidoEN
{
/**
 *	Atributo id
 */
private int id;



/**
 *	Atributo descripcion
 */
private string descripcion;



/**
 *	Atributo fecha
 */
private Nullable<DateTime> fecha;



/**
 *	Atributo cliente
 */
private EjemploDSMGenNHibernate.EN.EjemploDSM.ClienteEN cliente;



/**
 *	Atributo lineaPedido
 */
private System.Collections.Generic.IList<EjemploDSMGenNHibernate.EN.EjemploDSM.LineaPedidoEN> lineaPedido;






public virtual int Id {
        get { return id; } set { id = value;  }
}



public virtual string Descripcion {
        get { return descripcion; } set { descripcion = value;  }
}



public virtual Nullable<DateTime> Fecha {
        get { return fecha; } set { fecha = value;  }
}



public virtual EjemploDSMGenNHibernate.EN.EjemploDSM.ClienteEN Cliente {
        get { return cliente; } set { cliente = value;  }
}



public virtual System.Collections.Generic.IList<EjemploDSMGenNHibernate.EN.EjemploDSM.LineaPedidoEN> LineaPedido {
        get { return lineaPedido; } set { lineaPedido = value;  }
}





public PedidoEN()
{
        lineaPedido = new System.Collections.Generic.List<EjemploDSMGenNHibernate.EN.EjemploDSM.LineaPedidoEN>();
}



public PedidoEN(int id, string descripcion, Nullable<DateTime> fecha, EjemploDSMGenNHibernate.EN.EjemploDSM.ClienteEN cliente, System.Collections.Generic.IList<EjemploDSMGenNHibernate.EN.EjemploDSM.LineaPedidoEN> lineaPedido
                )
{
        this.init (Id, descripcion, fecha, cliente, lineaPedido);
}


public PedidoEN(PedidoEN pedido)
{
        this.init (Id, pedido.Descripcion, pedido.Fecha, pedido.Cliente, pedido.LineaPedido);
}

private void init (int id, string descripcion, Nullable<DateTime> fecha, EjemploDSMGenNHibernate.EN.EjemploDSM.ClienteEN cliente, System.Collections.Generic.IList<EjemploDSMGenNHibernate.EN.EjemploDSM.LineaPedidoEN> lineaPedido)
{
        this.Id = id;


        this.Descripcion = descripcion;

        this.Fecha = fecha;

        this.Cliente = cliente;

        this.LineaPedido = lineaPedido;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        PedidoEN t = obj as PedidoEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
