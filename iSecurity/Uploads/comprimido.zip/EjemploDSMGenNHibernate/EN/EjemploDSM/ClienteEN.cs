
using System;
// Definición clase ClienteEN
namespace EjemploDSMGenNHibernate.EN.EjemploDSM
{
public partial class ClienteEN
{
/**
 *	Atributo dNI
 */
private string dNI;



/**
 *	Atributo nombre
 */
private string nombre;



/**
 *	Atributo pedido
 */
private System.Collections.Generic.IList<EjemploDSMGenNHibernate.EN.EjemploDSM.PedidoEN> pedido;



/**
 *	Atributo apellidos
 */
private string apellidos;



/**
 *	Atributo contrasenya
 */
private String contrasenya;






public virtual string DNI {
        get { return dNI; } set { dNI = value;  }
}



public virtual string Nombre {
        get { return nombre; } set { nombre = value;  }
}



public virtual System.Collections.Generic.IList<EjemploDSMGenNHibernate.EN.EjemploDSM.PedidoEN> Pedido {
        get { return pedido; } set { pedido = value;  }
}



public virtual string Apellidos {
        get { return apellidos; } set { apellidos = value;  }
}



public virtual String Contrasenya {
        get { return contrasenya; } set { contrasenya = value;  }
}





public ClienteEN()
{
        pedido = new System.Collections.Generic.List<EjemploDSMGenNHibernate.EN.EjemploDSM.PedidoEN>();
}



public ClienteEN(string dNI, string nombre, System.Collections.Generic.IList<EjemploDSMGenNHibernate.EN.EjemploDSM.PedidoEN> pedido, string apellidos, String contrasenya
                 )
{
        this.init (DNI, nombre, pedido, apellidos, contrasenya);
}


public ClienteEN(ClienteEN cliente)
{
        this.init (DNI, cliente.Nombre, cliente.Pedido, cliente.Apellidos, cliente.Contrasenya);
}

private void init (string DNI, string nombre, System.Collections.Generic.IList<EjemploDSMGenNHibernate.EN.EjemploDSM.PedidoEN> pedido, string apellidos, String contrasenya)
{
        this.DNI = DNI;


        this.Nombre = nombre;

        this.Pedido = pedido;

        this.Apellidos = apellidos;

        this.Contrasenya = contrasenya;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        ClienteEN t = obj as ClienteEN;
        if (t == null)
                return false;
        if (DNI.Equals (t.DNI))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.DNI.GetHashCode ();
        return hash;
}
}
}
