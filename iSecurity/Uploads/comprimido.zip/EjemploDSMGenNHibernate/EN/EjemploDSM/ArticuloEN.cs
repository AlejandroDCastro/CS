
using System;
// Definición clase ArticuloEN
namespace EjemploDSMGenNHibernate.EN.EjemploDSM
{
public partial class ArticuloEN
{
/**
 *	Atributo id
 */
private int id;



/**
 *	Atributo lineaPedido
 */
private System.Collections.Generic.IList<EjemploDSMGenNHibernate.EN.EjemploDSM.LineaPedidoEN> lineaPedido;



/**
 *	Atributo descripcion
 */
private string descripcion;



/**
 *	Atributo precio
 */
private double precio;



/**
 *	Atributo categoria
 */
private EjemploDSMGenNHibernate.EN.EjemploDSM.CategoriaEN categoria;



/**
 *	Atributo url
 */
private string url;



/**
 *	Atributo nombre
 */
private string nombre;






public virtual int Id {
        get { return id; } set { id = value;  }
}



public virtual System.Collections.Generic.IList<EjemploDSMGenNHibernate.EN.EjemploDSM.LineaPedidoEN> LineaPedido {
        get { return lineaPedido; } set { lineaPedido = value;  }
}



public virtual string Descripcion {
        get { return descripcion; } set { descripcion = value;  }
}



public virtual double Precio {
        get { return precio; } set { precio = value;  }
}



public virtual EjemploDSMGenNHibernate.EN.EjemploDSM.CategoriaEN Categoria {
        get { return categoria; } set { categoria = value;  }
}



public virtual string Url {
        get { return url; } set { url = value;  }
}



public virtual string Nombre {
        get { return nombre; } set { nombre = value;  }
}





public ArticuloEN()
{
        lineaPedido = new System.Collections.Generic.List<EjemploDSMGenNHibernate.EN.EjemploDSM.LineaPedidoEN>();
}



public ArticuloEN(int id, System.Collections.Generic.IList<EjemploDSMGenNHibernate.EN.EjemploDSM.LineaPedidoEN> lineaPedido, string descripcion, double precio, EjemploDSMGenNHibernate.EN.EjemploDSM.CategoriaEN categoria, string url, string nombre
                  )
{
        this.init (Id, lineaPedido, descripcion, precio, categoria, url, nombre);
}


public ArticuloEN(ArticuloEN articulo)
{
        this.init (Id, articulo.LineaPedido, articulo.Descripcion, articulo.Precio, articulo.Categoria, articulo.Url, articulo.Nombre);
}

private void init (int id, System.Collections.Generic.IList<EjemploDSMGenNHibernate.EN.EjemploDSM.LineaPedidoEN> lineaPedido, string descripcion, double precio, EjemploDSMGenNHibernate.EN.EjemploDSM.CategoriaEN categoria, string url, string nombre)
{
        this.Id = id;


        this.LineaPedido = lineaPedido;

        this.Descripcion = descripcion;

        this.Precio = precio;

        this.Categoria = categoria;

        this.Url = url;

        this.Nombre = nombre;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        ArticuloEN t = obj as ArticuloEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
