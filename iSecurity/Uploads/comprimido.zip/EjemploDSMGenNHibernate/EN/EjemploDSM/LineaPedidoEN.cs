
using System;
// Definición clase LineaPedidoEN
namespace EjemploDSMGenNHibernate.EN.EjemploDSM
{
public partial class LineaPedidoEN
{
/**
 *	Atributo num
 */
private int num;



/**
 *	Atributo pedido
 */
private EjemploDSMGenNHibernate.EN.EjemploDSM.PedidoEN pedido;



/**
 *	Atributo cantidad
 */
private int cantidad;



/**
 *	Atributo articulo
 */
private EjemploDSMGenNHibernate.EN.EjemploDSM.ArticuloEN articulo;






public virtual int Num {
        get { return num; } set { num = value;  }
}



public virtual EjemploDSMGenNHibernate.EN.EjemploDSM.PedidoEN Pedido {
        get { return pedido; } set { pedido = value;  }
}



public virtual int Cantidad {
        get { return cantidad; } set { cantidad = value;  }
}



public virtual EjemploDSMGenNHibernate.EN.EjemploDSM.ArticuloEN Articulo {
        get { return articulo; } set { articulo = value;  }
}





public LineaPedidoEN()
{
}



public LineaPedidoEN(int num, EjemploDSMGenNHibernate.EN.EjemploDSM.PedidoEN pedido, int cantidad, EjemploDSMGenNHibernate.EN.EjemploDSM.ArticuloEN articulo
                     )
{
        this.init (Num, pedido, cantidad, articulo);
}


public LineaPedidoEN(LineaPedidoEN lineaPedido)
{
        this.init (Num, lineaPedido.Pedido, lineaPedido.Cantidad, lineaPedido.Articulo);
}

private void init (int num, EjemploDSMGenNHibernate.EN.EjemploDSM.PedidoEN pedido, int cantidad, EjemploDSMGenNHibernate.EN.EjemploDSM.ArticuloEN articulo)
{
        this.Num = num;


        this.Pedido = pedido;

        this.Cantidad = cantidad;

        this.Articulo = articulo;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        LineaPedidoEN t = obj as LineaPedidoEN;
        if (t == null)
                return false;
        if (Num.Equals (t.Num))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Num.GetHashCode ();
        return hash;
}
}
}
