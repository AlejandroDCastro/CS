
using System;
using EjemploDSMGenNHibernate.EN.EjemploDSM;

namespace EjemploDSMGenNHibernate.CAD.EjemploDSM
{
public partial interface ICategoriaCAD
{
CategoriaEN ReadOIDDefault (int id);

int New_ (CategoriaEN categoria);

void Modify (CategoriaEN categoria);


void Destroy (int id);


CategoriaEN ReadOID (int id);


System.Collections.Generic.IList<CategoriaEN> ReadAll (int first, int size);
}
}
