
using System;
using EjemploDSMGenNHibernate.EN.EjemploDSM;

namespace EjemploDSMGenNHibernate.CAD.EjemploDSM
{
public partial interface ILineaPedidoCAD
{
LineaPedidoEN ReadOIDDefault (int num);

int New_ (LineaPedidoEN lineaPedido);

void Modify (LineaPedidoEN lineaPedido);


void Destroy (int num);
}
}
