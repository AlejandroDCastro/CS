
using System;
using EjemploDSMGenNHibernate.EN.EjemploDSM;

namespace EjemploDSMGenNHibernate.CAD.EjemploDSM
{
public partial interface IClienteCAD
{
ClienteEN ReadOIDDefault (string DNI);

string New_ (ClienteEN cliente);

void Modify (ClienteEN cliente);


void Destroy (string DNI);
}
}
