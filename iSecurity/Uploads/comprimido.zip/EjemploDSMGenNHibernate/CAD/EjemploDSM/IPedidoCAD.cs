
using System;
using EjemploDSMGenNHibernate.EN.EjemploDSM;

namespace EjemploDSMGenNHibernate.CAD.EjemploDSM
{
public partial interface IPedidoCAD
{
PedidoEN ReadOIDDefault (int id);

int New_ (PedidoEN pedido);

void Modify (PedidoEN pedido);


void Destroy (int id);
}
}
