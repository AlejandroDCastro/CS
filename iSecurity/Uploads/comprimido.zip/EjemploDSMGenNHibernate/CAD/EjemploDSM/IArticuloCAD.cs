
using System;
using EjemploDSMGenNHibernate.EN.EjemploDSM;

namespace EjemploDSMGenNHibernate.CAD.EjemploDSM
{
public partial interface IArticuloCAD
{
ArticuloEN ReadOIDDefault (int id);

int New_ (ArticuloEN articulo);

void Modify (ArticuloEN articulo);


void Destroy (int id);


ArticuloEN ReadOID (int id);


System.Collections.Generic.IList<ArticuloEN> ReadAll (int first, int size);


System.Collections.Generic.IList<EjemploDSMGenNHibernate.EN.EjemploDSM.ArticuloEN> DameArticulosPorCat (int p_categoria);
}
}
