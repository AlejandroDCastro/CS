
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using EjemploDSMGenNHibernate.EN.EjemploDSM;
using EjemploDSMGenNHibernate.CAD.EjemploDSM;

namespace EjemploDSMGenNHibernate.CEN.EjemploDSM
{
public partial class ClienteCEN
{
public bool Login (string p_oid, string contrasenya)
{
        /*PROTECTED REGION ID(EjemploDSMGenNHibernate.CEN.EjemploDSM_Cliente_login) ENABLED START*/

        bool result = false;
        ClienteEN en = _IClienteCAD.ReadOIDDefault (p_oid);

        if (en.Contrasenya.Equals (Utils.Util.GetEncondeMD5 (contrasenya)))
                result = true;
        return result;

        /*PROTECTED REGION END*/
}
}
}
