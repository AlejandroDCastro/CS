

using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using EjemploDSMGenNHibernate.EN.EjemploDSM;
using EjemploDSMGenNHibernate.CAD.EjemploDSM;

namespace EjemploDSMGenNHibernate.CEN.EjemploDSM
{
/*
 *      Definition of the class LineaPedidoCEN
 *
 */
public partial class LineaPedidoCEN
{
private ILineaPedidoCAD _ILineaPedidoCAD;

public LineaPedidoCEN()
{
        this._ILineaPedidoCAD = new LineaPedidoCAD ();
}

public LineaPedidoCEN(ILineaPedidoCAD _ILineaPedidoCAD)
{
        this._ILineaPedidoCAD = _ILineaPedidoCAD;
}

public ILineaPedidoCAD get_ILineaPedidoCAD ()
{
        return this._ILineaPedidoCAD;
}

public int New_ (int p_pedido, int p_cantidad, int p_articulo)
{
        LineaPedidoEN lineaPedidoEN = null;
        int oid;

        //Initialized LineaPedidoEN
        lineaPedidoEN = new LineaPedidoEN ();

        if (p_pedido != -1) {
                // El argumento p_pedido -> Property pedido es oid = false
                // Lista de oids num
                lineaPedidoEN.Pedido = new EjemploDSMGenNHibernate.EN.EjemploDSM.PedidoEN ();
                lineaPedidoEN.Pedido.Id = p_pedido;
        }

        lineaPedidoEN.Cantidad = p_cantidad;


        if (p_articulo != -1) {
                // El argumento p_articulo -> Property articulo es oid = false
                // Lista de oids num
                lineaPedidoEN.Articulo = new EjemploDSMGenNHibernate.EN.EjemploDSM.ArticuloEN ();
                lineaPedidoEN.Articulo.Id = p_articulo;
        }

        //Call to LineaPedidoCAD

        oid = _ILineaPedidoCAD.New_ (lineaPedidoEN);
        return oid;
}

public void Modify (int p_LineaPedido_OID, int p_cantidad)
{
        LineaPedidoEN lineaPedidoEN = null;

        //Initialized LineaPedidoEN
        lineaPedidoEN = new LineaPedidoEN ();
        lineaPedidoEN.Num = p_LineaPedido_OID;
        lineaPedidoEN.Cantidad = p_cantidad;
        //Call to LineaPedidoCAD

        _ILineaPedidoCAD.Modify (lineaPedidoEN);
}

public void Destroy (int num)
{
        _ILineaPedidoCAD.Destroy (num);
}
}
}
